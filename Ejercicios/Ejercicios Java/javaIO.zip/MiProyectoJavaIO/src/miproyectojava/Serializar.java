
package miproyectojava;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;


public class Serializar {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        
        PersonaExternalizable persona=new PersonaExternalizable("Doctor Mosca", 47);
        System.out.println("vamos a enviar()"+persona);
        
        FileOutputStream fos=new FileOutputStream("d:\\javam\\datos.dat");
        ObjectOutputStream oos=new  ObjectOutputStream(fos);
        oos.writeObject(persona);
        oos.flush();//
        oos.close();
        fos.close();
        
    }
}
