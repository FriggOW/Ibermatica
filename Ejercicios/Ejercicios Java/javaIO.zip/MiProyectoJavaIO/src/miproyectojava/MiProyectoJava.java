
package miproyectojava;


public class MiProyectoJava {

    public static void main(String[] args) {
        System.out.println("esto es un hola mundo");
    }

}
