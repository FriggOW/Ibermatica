
package miproyectojava;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.Serializable;
import java.util.Objects;


public class PersonaExternalizable implements Externalizable{
 
        String nombre;
        int edad;

    public PersonaExternalizable(){}
    
    public PersonaExternalizable(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "Persona{" + "nombre=" + nombre + ", edad=" + edad + '}';
    }


    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + Objects.hashCode(this.nombre);
        hash = 37 * hash + this.edad;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final PersonaExternalizable other = (PersonaExternalizable) obj;
        if (this.edad != other.edad) {
            return false;
        }
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        return true;
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
       //this.nombre=(String) in.readObject();
       this.nombre=in.readUTF();
        this.edad=in.readInt();
    }
        
    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeUTF("*****"+this.nombre.toUpperCase()+"*****");
         out.writeInt(this.edad);
    }

   
}
