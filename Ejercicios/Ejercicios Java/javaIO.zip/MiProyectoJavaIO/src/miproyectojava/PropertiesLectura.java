
package miproyectojava;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;


public class PropertiesLectura {
   
    public static void main(String[] args) {        
        Properties propiedadesLeidas=new Properties();
        File fichero=new File("d:\\javam\\miConfiguracion.properties");  
        
        try {
            FileInputStream fis=new FileInputStream(fichero);
            
            propiedadesLeidas.load(fis);
            
            System.out.println("valor obtenido1="+propiedadesLeidas.getProperty("nombre"));
             System.out.println("valor obtenido2="+propiedadesLeidas.getProperty("edad"));
             System.out.println("valor obtenido3="+propiedadesLeidas.getProperty("claveInexistente","me lo invento"));
            
             Enumeration enumer=propiedadesLeidas.keys();
             while(enumer.hasMoreElements()){
                 String clave=(String) enumer.nextElement();
                 String valor=propiedadesLeidas.getProperty(clave);
                 
                 System.out.println("clave: "+clave+">>>>>>>>>"+valor);
                 
             }
             
             
             
        } catch (IOException ex) {
           ex.printStackTrace();
        } 
        
    }
}
