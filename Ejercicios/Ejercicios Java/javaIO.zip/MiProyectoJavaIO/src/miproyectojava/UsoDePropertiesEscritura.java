
package miproyectojava;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UsoDePropertiesEscritura {
    
    public static void main(String[] args) throws Exception{
        
        
            Properties propiedades=new Properties();
            propiedades.setProperty("nombreClave", "valor de la clave");
            propiedades.setProperty("nombre", "alejandro");
            propiedades.setProperty("edad", "47");
            propiedades.setProperty("apellido1", "jimenez");
            propiedades.setProperty("apellido2", "Vitoria");
            File fichero=new File("d:\\javam\\miConfiguracion.xml");
            
            FileOutputStream fos=null;           
            fos = new FileOutputStream(fichero);
            
            propiedades.storeToXML(fos, "una cabecera para mi fichero de configuracion");
          
    }
    
}
