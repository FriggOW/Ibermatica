
package miproyectojava;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;


public class Deserializar {


    public static void main(String[] args) throws FileNotFoundException, 
                                            IOException, ClassNotFoundException {
      
        PersonaExternalizable personaRecuperada;
        FileInputStream fis=new FileInputStream("d:\\javam\\datos.dat");
        ObjectInputStream ois=new ObjectInputStream(fis);
        personaRecuperada=(PersonaExternalizable) ois.readObject();
        
        ois.close();
        fis.close();
        
        System.out.println("hemos leido a "+personaRecuperada);
    }
    
}
