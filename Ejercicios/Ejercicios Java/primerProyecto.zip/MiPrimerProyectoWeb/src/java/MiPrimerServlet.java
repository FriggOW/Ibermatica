
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MiPrimerServlet extends HttpServlet {

    public void doPost(HttpServletRequest peticion,
            HttpServletResponse respuesta) {

        procesar(peticion, respuesta);
    }

    public void doGet(HttpServletRequest peticion,
            HttpServletResponse respuesta) {
        procesar(peticion, respuesta);
    }

    public void procesar(HttpServletRequest peticion,
            HttpServletResponse respuesta) {

        PrintWriter out = null;
    
        try {
            respuesta.setContentType("text/html");
            out = respuesta.getWriter();
            
            out.println("<!DOCTYPE html>");
      
            out.println("<html>\n" +
                        "    <head>\n" +
                        "        <title>Hola mundo servlet</title>\n" +
                        "    </head>\n" +
                        "    <body>\n" +
                        "        <h1>MI PRIMERA APLICACIONdddddddddd</h1>\n" +
                        "    </body>\n" +
                        "</html>");
         
        } catch (Exception ex) {
            System.err.println("se ha producido una excepcion "
                    +ex.getMessage());
        } finally{
               out.close();
        }
    }
}
